<?php

include_once ('connect.php');
include_once ('./utils/utils.php');

header("Location: $lang");
